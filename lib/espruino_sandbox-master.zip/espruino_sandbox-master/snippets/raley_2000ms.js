var  on = false;
setInterval(function() {
  on = !on;
  LED1.write(on);
  //digitalWrite(P8,255);
  //console.log(P8.read());
}, 1000);