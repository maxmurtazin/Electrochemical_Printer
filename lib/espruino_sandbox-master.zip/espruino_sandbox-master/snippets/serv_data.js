// Настраиваем соединение с Ethernet Shield по протоколу SPI.
SPI2.setup({baud: 3200000, mosi: B15, miso: B14, sck: B13});
var eth = require('WIZnet').connect(SPI2, P10);
// Получаем и выводим IP-адрес от DHCP-сервера
eth.setIP();
print(eth.getIP());
 
require("http").createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.write('<html><head></head><body>');
  res.write('<p2>Hello</p2>');
  res.write(dataArray[0]);
  res.write('</body></html>');
  res.end();
}).listen(8080);


var mux1 = A0;// analog pin cinnected to mux1
var mux2 = A1; //analog pin connected to mux 2
var S0_PIN = P13;// multyplex select digital pins
var S1_PIN = P7;// multyplex select digital pins
var S2_PIN = P9;// multyplex select digital pins
var dataArray = new Array (16);

for (var i=0; i<8; i++) { 
  digitalWrite ( S0_PIN, i & 0x01);
  digitalWrite ( S1_PIN, i>>1 & 0x01);
  digitalWrite ( S2_PIN, i>>2 & 0x01);
  dataArray[i]=analogRead(mux1);
  dataArray[i+8]=analogRead(mux2);
} 

