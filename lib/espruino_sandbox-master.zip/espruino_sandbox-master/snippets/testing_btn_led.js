var on=false;
var LEDon=false;
var s=0;

// Сокращения:
prnt=console.log;
ar=analogRead;
aw=analogWrite;
dr=digitalRead;
dw=digitalWrite;

// Пины P0-P7, SCL (?), SDA (?),A0-A5:
ap=[A0,A1,A2,A3,A4,A5,A6,A7,B0,B1,C0,C1,C2,C3,C4,C5];


function AR(pin){prnt('Pin ' + pin + ': ' + ar(pin));}

//НАЧАЛО:
prnt('Press BTN1 or type "on=true"...');

// Наблюдаем за кнопкой, сохраняем id для функции clearWatch
var idWatch = setWatch(function(e) {
  on=!on;
  prnt('on='+on);
}, BTN1, {
  repeat: true,
  edge: 'falling',
  debounce: 10
});

// Повторяем с определенной периодичностью
setInterval(function() {
  if (on) {
    LEDon=!LEDon;
    LED1.write(LEDon);

    s++; prnt(s+' sec');

    t=getTime();
    for(i=0;i<ap.length;i++){AR(ap[i]);}
    t=getTime()-t;
    prnt('for(i=0;i<ap.length;i++){AR(ap[i]);}\nTIME = '+t*1000+' ms');

    t=getTime();
    ap.forEach(function(p){AR(p);});
    t=getTime()-t;
    prnt('ap.forEach(function(p){AR(p);});\nTIME = '+t*1000+' ms');
  }
}, 1000);
