# Espruino sandbox

**Полезные ссылки:**

*  [Как быстрее "делать ноги" с Iskra JS или тайная сила "compile";](http://forum.amperka.ru/threads/%D0%9A%D0%B0%D0%BA-%D0%B1%D1%8B%D1%81%D1%82%D1%80%D0%B5%D0%B5-%D0%B4%D0%B5%D0%BB%D0%B0%D1%82%D1%8C-%D0%BD%D0%BE%D0%B3%D0%B8-%D1%81-iskra-js-%D0%B8%D0%BB%D0%B8-%D1%82%D0%B0%D0%B9%D0%BD%D0%B0%D1%8F-%D1%81%D0%B8%D0%BB%D0%B0-compile.12127/)
*  [Амперка: JavaScript в микроконтроллере](http://wiki.amperka.ru/js:start)
*  [Espruino shiftOut](https://www.espruino.com/Reference#l__global_shiftOut)

### Настройки **Espruino IDE** для **Iskra JS** (Амперка):

Espruino Web IDE -> Settings -> Project -> Select directory for Sandbox

Затем в этой директории делаем:

```
git init
git remote add gl git@gl.tgrapps.ru:membranes/espruino_sandbox.git
git pull gl master
```

Для внесения изменений в репозиторий:

```
git add .
git commit -m 'обновление'
git push --set-upstream gl master
```

После этого можно каждый раз делать просто:

```
git pull && git add . && git commit -m 'обновление' && git push
```