module.exports = {
  indexTitle: {
    en: 'EDR-Z unit',
    ru: 'Установка EDR-Z'
  }
}
