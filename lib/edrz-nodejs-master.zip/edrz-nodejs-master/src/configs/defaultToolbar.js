module.exports = {
  toolbarClsName: 'EDRZ2H'
}
