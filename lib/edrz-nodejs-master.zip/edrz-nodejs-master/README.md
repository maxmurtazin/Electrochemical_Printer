# EDRZ Node.js+Express backend

For **docker-compose** instructions see **EDRZ Full** project.

### Project setup
```
npm install
```

#### Compiles and hot-reloads for development
```
npm start
```