# EDRZ unit control panel: client (Vue) + server (Express, MongoDB) part

### Submodules:

`membranes/edrz-vuetify.git` -- client

`membranes/edrz-nodejs.git` -- server

Clone with submodules:

```
git clone --recurse-submodules -j2
```

Pull with submodules:

```
git pull --recurse-submodules -j2
```

Push with submodules:

```
git push --recurse-submodules=on-demand
```

## Client

### Project setup
```
npm install
```

#### Compiles and hot-reloads for development
```
npm run serve
```

#### Compiles and minifies for production
```
npm run build
```

#### Lints and fixes files
```
npm run lint
```

#### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).

## Server

### Project setup
```
npm install
```
#### Compiles and hot-reloads for development
```
npm run devstart
```

#### Run production server
```
node ./bin/www
```
or
```
npm start
```
or (with DEBUG env)
```
npm run serverstart
```

## Docker-compose

### Build containers

```
docker-compose build --parallel --no-cache
```

### Down containers

```
docker-compose down
```

### Run containers

```
docker-compose up -d
```

# Build and deploy using docker-compose

### Prerequisites:

* docker
* docker-compose

### Ports:

* Client - 80
* Server - 8081
* Mongo - 27018

(See `utils/docker-compose.yml`)

### Setup:

* View utils shell scripts in `/utils`, change environments in `/utils/env`

```
cd utils
```

* **!!! Change git links in** `/utils/env` **!!!**
 
* Create files `mongo-init.js`, `mongo.env` and `server.env` and set passwords in 

`mongo.env`

```
MONGO_INITDB_DATABASE=admin
MONGO_INITDB_ROOT_USERNAME=admin
MONGO_INITDB_ROOT_PASSWORD=adminpassword
```

`server.env`

```
MONGO_USERNAME=user
MONGO_PASSWORD=userpassword
MONGO_HOSTNAME=mongo
MONGO_DB=dbname
MONGO_PORT=27017
SERVER_PORT=8081
```

`mongo-init.js`

```
db.auth('admin', 'adminpassword');

db.createUser(
  {
    user: "user",
    pwd: "userpassword",
    roles: [
      {
          role: "readWrite",
          db: "dbname"
      }
    ]
  }
);
```

* Don't forget to change permissions:

```
chmod 600 mongo-init.js
chmod 600 mongo.env
chmod 600 server.env
```

* Make sure that you can access git repositories with root

* Build & run project:

```
sudo sh build-deploy.sh
```