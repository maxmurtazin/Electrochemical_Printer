#!/bin/bash
DIRECTORY=/app
RECORDS=/app/data/records
DATABASE=/app/data/db
DATABASE_PORT=27018
SERVER_PORT=8081
HTTP_PORT=80
HTTPS_PORT=443
if [ -f env ]; then
  export $(cat env | sed 's/#.*//g' | xargs)
fi
cd "$DIRECTORY"
docker-compose up -d