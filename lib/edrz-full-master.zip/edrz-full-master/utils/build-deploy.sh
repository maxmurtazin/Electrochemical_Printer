#!/bin/bash
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit
fi

DIRECTORY=/app
RECORDS=/app/data/records
DATABASE=/app/data/db
DATABASE_PORT=27018
SERVER_PORT=8081
HTTP_PORT=80
HTTPS_PORT=443
GIT_FULL="https://gl.membranes.site/membranes/edrz-full.git"

if [ -f env ]; then
  export $(cat env | sed 's/#.*//g' | xargs)
fi

if [ ! -d "$DIRECTORY" ]; then
  mkdir "$DIRECTORY"
  git clone --recurse-submodules -j2 "$GIT_FULL" "$DIRECTORY/"
fi

if [ ! -d "$RECORDS" ]; then
  mkdir -p "$RECORDS"
fi

cp docker-compose.yml "$DIRECTORY/"
cp mongo-init.js "$DIRECTORY/"
cp mongo.env "$DIRECTORY/"
cp server.env "$DIRECTORY/"
cp client.env "$DIRECTORY/"
cp ../docker-compose.yml "$DIRECTORY/"
cp ../mongo-init.js "$DIRECTORY/"
cp ../mongo.env "$DIRECTORY/"
cp ../server.env "$DIRECTORY/"
cp ../client.env "$DIRECTORY/"
cd "$DIRECTORY"

chown 999 mongo-init.js
chmod 600 mongo-init.js
chmod 600 mongo.env
chmod 600 server.env

if [ ! -d "$DATABASE" ]; then
  mkdir -p "$DATABASE"
fi
chown 999 "$DATABASE" -R

cd "$DIRECTORY"
git pull --recurse-submodules -j2

docker-compose build --parallel --no-cache --build-arg "CACHEBUST=$(date +%s) ."
docker-compose down
docker-compose up -d
