#!/bin/bash
if [ "$EUID" -ne 0 ]; then
  echo "Please run as root"
  exit
fi

DIRECTORY=/app
RECORDS=/app/data/records
DATABASE=/app/data/db
DATABASE_PORT=27018
SERVER_PORT=8081
HTTP_PORT=80
HTTPS_PORT=443
if [ -f env ]; then
  export $(cat env | sed 's/#.*//g' | xargs)
fi

if [ -d "$DIRECTORY" ]; then
  cd "$DIRECTORY"
  git pull --recurse-submodules -j2
fi

docker-compose build --parallel --build-arg "CACHEBUST=$(date +%s) ."
docker-compose down
docker-compose up -d
